abstract interface Measurable {
    abstract double getArea();
}
