abstract class Shape implements Measurable {
    abstract String getName();
}
