public class Car extends Vehicle {
	void Start() {
		System.out.println("Car ignition turns on");
	}

	void honk() {
		System.out.println("Car honks");
	}

	public static void main(string [] args) {

	}
}
