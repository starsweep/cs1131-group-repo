public class Birb extends Animal{
	void sound(){
		System.out.println("IMA BIRB");
		
	}

}
