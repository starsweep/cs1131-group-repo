public class Book {
  public void type() {
    System.out.println("A mysterious unknown book");
  }
}
