public class TextFile extends Book {
    public void type() {
        System.out.println("This book is unformatted, and can be read on a screen");
    }
}
