public class Week10Lab{

	public boolean isPalindrome(String s){
		boolean palinbool = false;
		String reverse = "";

		for(int i=0; i <= s.length()-1; i++)
		{
			System.out.println("hit");
		
			reverse += s.charAt(s.length()-i);

			System.out.println("Original = "+s+"\n Reverse"+reverse);


		}

		if (reverse.equalsIgnoreCase(s))
		{
			palinbool = true;

		}


	return palinbool;

}

}
